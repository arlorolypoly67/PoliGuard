# PoliGuard 1.0 User Manual 🛡️

PoliGuard is a lightweight antivirus tool designed for real-time protection, manual scans, and quarantine management. This manual explains the features, UI, and usage of PoliGuard 1.0.

---

## 1. Installation

1. Extract all files from the ZIP to a folder.
2. Run `PoliGuard.exe`.
3. To enable full system scans with admin privileges, right-click the executable and select **Run as administrator** or use the `--fullscan` flag.

---

## 2. User Interface Overview

PoliGuard has four main tabs:

1. **Home** – Quick access to scans and real-time monitoring.
2. **Scan** – Perform quick, custom, or full scans.
3. **Quarantine** – Manage quarantined files.
4. **Real-Time Monitor** – Toggle and monitor ongoing protection.

### 2.1 Home Tab

- **Quick Scan button** – Start a quick scan of common folders (Downloads, Desktop, Documents, Program Files).
- **Check Quarantine button** – Navigate to the Quarantine tab.
- **Real Time Monitor button** – Navigate to real-time monitoring controls.

---

### 2.2 Scan Tab

- **Quick Scan** – Scans default folders for viruses.
- **Custom Scan** – Scan a selected folder.
- **Custom Scan File** – Scan a single file for known virus signatures.
- **Full Scan** – Requires admin; scans the entire system (`C:/`).
- **Quarantine (Q) Button** – Move selected threats to quarantine.
- **Delete (D) Button** – Permanently delete selected threats from the list.
- **Log Window** – Shows scanning progress and detected threats.

---

### 2.3 Quarantine Tab

- **Remove** – Delete selected files from quarantine.
- **Restore** – Restore quarantined files to their original location.
- **Quarantine List** – Displays all quarantined files.
- PoliGuard maintains a log at `quarantine/log.txt` for all quarantined actions.

---

### 2.4 Real-Time Monitor Tab

- **Toggle Switch** – Turn real-time protection **ON/OFF**.
    - Green = ON
    - Red = OFF
- **Real-Time Log Window** – Displays files detected automatically by real-time protection.
- Real-time protection monitors:
    - Downloads
    - Desktop
    - Documents
- Notifications are sent for detected threats using Windows Toast notifications.

---

## 3. Features

### 3.1 Realtime Protection

- Monitors key user folders continuously.
- Detects files matching MD5 hashes listed in `virushashes.txt`.
- Automatically quarantines or logs threats.
- Can be enabled/disabled using the toggle switch or buttons in the Home tab.

---

### 3.2 Virus Scanning

- **Quick Scan** – Scans main folders quickly.
- **Custom Scan** – User-selected folder scan.
- **Custom File Scan** – Checks a specific file against virus signatures.
- **Full Scan** – Scans the entire system for threats (admin required).

MD5 hashing is used to identify known malware.

---

### 3.3 Quarantine Management

- Files moved to `quarantine` folder are automatically locked with restricted permissions.
- Logs are maintained in `quarantine/log.txt`.
- Users can restore or permanently delete files from quarantine.
- Restoration preserves original paths and backs up existing files if conflicts exist.

---

### 3.4 File Permissions (Lock/Unlock)

- PoliGuard can block or unblock file access.
- **Locking**: Denies read for everyone, full control for admins.
- **Unlocking**: Restores read access for everyone and full control for admins.
- Used for quarantined files to prevent accidental access.

---

## 4. Configuration Files

- `virushashes.txt` – List of known virus MD5 hashes.
- `rl.flag` – Stores real-time protection state (`true`/`false`).
- `quarantine/log.txt` – Tracks quarantined files and timestamps.

---

## 5. Running as Administrator

- Full system scans require elevated privileges.
- PoliGuard can automatically restart itself with admin rights if needed.
- Without admin, full scan attempts will prompt for elevation.

---

## 6. Quick Tips

- Always load the latest `virushashes.txt` to detect new threats.
- Use **Real-Time Monitor** for continuous protection.
- Backup important files before restoring from quarantine.
- Use **Custom Scan** to check external drives or unusual folders.

---

## 7. Contact / Support

For issues or support, contact the developer:  
**Polibug / PoliGuard Team**

---

*PoliGuard 1.0 – Keeping your PC safe, one scan at a time.*